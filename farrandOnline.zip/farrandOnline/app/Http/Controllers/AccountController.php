<?php


namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Account;
use App\Order;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

# Class to deal with all account related functions
class AccountController extends Controller
{
    # Will create a new account in the database from a POST request
    public function register(Request $request) {

        # Try to validate data
        try {
            $this->validate($request, [
                'name' => 'bail|required|string|max:64',
                'email' => 'bail|required|email|unique:accounts',
                'password' => 'bail|required|min:6',
                'studentId' => 'bail|integer|required',
                'school' => 'bail|required|string',
                'verification' => 'bail|required|string'
            ]);
        }
        catch (\Illuminate\Validation\ValidationException $e) {
            print_r($e);
            exit();
        }

        // Check verification
        if (!$request->request->get('verification') === 'ZTLMRfyEknlL86jjJ02SLwed3rzoKT4RCCX5dBQaJE6GT2tzjSSap4iaChTI') {
            return redirect()->to('/');
        }

        try {
            // Create array of all validated data
            $validatedData = ['name' => $request->request->get('name'), 'email' => $request->request->get('email'),
                'password' => Hash::make($request->request->get('password')), 'studentId' => $request->request->get('studentId'),
                'school' => $request->request->get('school')];

            // Create new user
            $user = null;
            $user = new Account($validatedData);

            $user->save();

            // Return User ID to C++
            return response('Account Id: ' . $user->id, 200);
        }
        catch (\Exception $e) {
            return response('Error creating account', 400);
        }
    }

    // Return login page view
    public function loginView() {
        // Check if user exists already, if so redirect them
        if (Auth::check() || Auth::viaRemember()) {
            return redirect()->to('/viewOrders');
        }

        return view('login', ['email' => null, 'messages' => null]);
    }

    // Function to login user via POST request via C++
    public function loginPost(Request $request) {
        // Validate data
        $this->validate($request, [
            "email" => 'bail|required|email',
            "password" => 'bail|required|string|min:6',
            "school" => 'bail|required|string',
            "verification" => 'bail|required|string'
        ]);

        // Check verification
        if (!$request->request->get('verification') === 'c6jk0sBEegr4KMHLUNfRYc2XSWgUSKgZEIbUZpvyvP5MxGhcAZdFJhxy8T9b') {
            return redirect()->to('/');
        }

        // Try to login, if successful return the account id to C++
        try {
            $credentials = $request->only(['email', 'password', 'school']);

            if (Auth::attempt($credentials, 1)) {
                return response('Account Id: ' . Auth::id(), 200);
            }
            else {
                return response('Invalid Credentials, please check and try again.', 400);
            }
        }

        catch (\Exception $e) {
            return response("Error logging in", 400);
        }

        return response('Other Error', 400);
    }

    // Function to show register page on website
    public function registerView() {
        // Check if user exists already
        if (Auth::check() || Auth::viaRemember()) {
            return redirect()->to('/viewOrders');
        }

        return view('register', ['email' => null, 'messages' => null]);
    }

    // Function to register via POST request on website
    public function registerFormPost(Request $request) {
        // Validate data
        $this->validate($request, [
            "name" => "bail|required|string",
            "email" => 'bail|required|email',
            "password" => 'bail|required|string|min:6',
            "school" => 'bail|required|string',
            "studentId" => 'bail|required|integer'
        ]);

        // Create array of data, hash password using Bcrypt
        try {
            $validatedData = ['name' => $request->request->get('name'), 'email' => $request->request->get('email'),
                'password' => Hash::make($request->request->get('password')), 'studentId' => $request->request->get('studentId'),
                'school' => $request->request->get('school')];

            // Create new user
            $user = null;
            $user = new Account($validatedData);

            // Add user to DB
            $user->save();

            // Login user on website via cookie
            Auth::login($user);

            return redirect()->to('/viewOrders');
        }

        catch (\Exception $e) {
            return view('register', ['email' => null, 'messages' => null])->withErrors(['accNotFound' => 'Problem Registering']);
        }
    }

    // Function to login via the website
    public function loginFormPost(Request $request) {
        // Validate data
        $this->validate($request, [
            "email" => 'bail|required|email',
            "password" => 'bail|required|string|min:6',
            "school" => 'bail|required|string',
        ]);

        // Try to login, if successful redirect user to the queue page
        try {
            $credentials = $request->only(['email', 'password', 'school']);

            if (Auth::attempt($credentials, 1)) {
                return redirect()->to('/viewOrders');
            }
            else {
                return view('login', ['email' => null, 'messages' => null])->withErrors(['accNotFound' => 'Account not found']);
            }
        }

        catch (\Exception $e) {
            return view('login', ['email' => null, 'messages' => null])->withErrors(['accNotFound' => 'Account not found']);
        }
    }
    
    public function homeRedirect() {
        return redirect()->to('/');
    }
}