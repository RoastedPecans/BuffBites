<?php


namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Account;
use App\Order;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

// Controller to deal with all the order functions
class OrderController extends Controller {

    // Create order via POST request (from C++)
    public function createOrder(Request $request) {
        # Validate data from POST request
        $this->validate($request, [
            'orderType' => 'bail|required|string',
            'orderData' => 'bail|required',
            'orderLocation' => 'bail|required|string',
            'id' => 'bail|required|exists:accounts|integer',
            'verification' => 'bail|required|string'
        ]);

        // Check verification
        if (!$request->request->get('verification') === 'rtkVM8uOpxqZVYBop5zNs8X6WS6pppMBHgd1CqxDZFXwqoXkkzY0jZaa0wcI') {
            return redirect()->to('/');
        }

        # Save validated data in a variable
        $validatedData = json_encode($request->request->get('orderData'));

        # Create new order model
        $order = null;
        $order = new Order();


        # Update values to have correct values
        $order->orderData = $validatedData;
        $order->orderType = $request->request->get('orderType');
        $order->accountId = $request->request->get('id');
        $order->orderLocation = $request->request->get('orderLocation');
        $order->completed = 0;
        $order->createdAt = time();
        $order->started = 0;

        # Save order in database
        $order->save();

        # Return response
        return response('Order Id: ' . $order->id, 200);

    }

    // Get + Return the correct data for the queue/orders page
    public function viewOrders() {
        // Ensure user is logged in
        $user = Auth::user();
        $sortedOrdersInQueue = array();

        // If admin user, get ALL orders, otherwise only orders belonging to account
        if ($user->admin === 1) {
            $ordersInQueue = Order::where('completed', 0)->where('started', 0)->where('completed', 0)->get();
            $ordersStarted = Order::where('started', 1)->where('completed', 0)->orderBy('timeToFinish', 'ASC')->get();
        }
        else {
            $ordersInQueue = Order::where('completed', 0)->where('started', 0)->where('accountId', $user->id)->get();
            $ordersStarted = Order::where('started', 1)->where('accountId', $user->id)->where('completed', 0)->orderBy('timeToFinish', 'ASC')->get();
        }

        // Variables to sort orders in queue
        $wellFlag = true;
        $mediumWellFlag = true;
        $mediumFlag = true;
        $mediumRareFlag = true;
        $rareFlag = true;
        $rareFlag2 = true;
        // Go through each order and sort by cooktime with the longest cooktimes (well) being at the front
        while ($rareFlag2) {
            foreach ($ordersInQueue as $order) {
                if ($wellFlag and json_decode($order->orderData)->cookType === 'well') {
                    $sortedOrdersInQueue[] = $order;
                }
                elseif (!$wellFlag and $mediumWellFlag and strtolower(json_decode($order->orderData)->cookType) === 'medium-well') {
                    $sortedOrdersInQueue[] = $order;
                }
                elseif (!$mediumWellFlag and $mediumFlag and strtolower(json_decode($order->orderData)->cookType) === 'medium') {
                    $sortedOrdersInQueue[] = $order;
                }
                elseif (!$mediumFlag and $mediumRareFlag and strtolower(json_decode($order->orderData)->cookType) === 'medium-rare') {
                    $sortedOrdersInQueue[] = $order;
                }
                elseif (!$mediumRareFlag and $rareFlag and strtolower(json_decode($order->orderData)->cookType) === 'rare') {
                    $sortedOrdersInQueue[] = $order;
                }
            }
            if (!$rareFlag) {
                $rareFlag2 = false;
            }
            if (!$mediumRareFlag) {
                $rareFlag = false;
            }
            if (!$mediumFlag) {
                $mediumRareFlag = false;
            }
            if (!$mediumWellFlag) {
                $mediumFlag = false;
            }
            if (!$wellFlag) {
                $mediumWellFlag = false;
            }
            if ($wellFlag) {
                $wellFlag = false;
            }
        }

        // Put all the toppings into an array that we will pass to the view. The array makes it much easier to display
        // The toppings on html webpage
        $orderToppings = array();
        foreach ($ordersInQueue as $order) {
            if (!empty(json_decode($order->orderData)->toppings)) {
                $orderToppings[$order->id] = array_values(get_object_vars(json_decode($order->orderData)->toppings));
            }
        }
        foreach ($ordersStarted as $order) {
            if (!empty(json_decode($order->orderData)->toppings)) {
                $orderToppings[$order->id] = array_values(get_object_vars(json_decode($order->orderData)->toppings));
            }
        }

        return view('queue', ["ordersInQueue" => $sortedOrdersInQueue, 'orderToppings' => $orderToppings, 'ordersStarted' => $ordersStarted, 'admin' => $user->admin]);
    }

    // Called when "start order" button clicked by admin user
    // Marks order as started and "calculates" how long to cook the burger before flipping it and how long in total to cook
    // the burger (i.e. cook on one side until flipTime hit, then flip and wait for finishTime to be 0 so each side
    // gets the same amount of cooktime)
    public function startOrder(Request $request) {
        $this->validate($request, [
           'orderId' => 'bail|required|string'
        ]);

        // Get order from database
        $orderToUpdate = Order::where('id', $request->request->get('orderId'))->first();
        $orderToUpdate->started = 1;

        // Get the cook type as a lowercase string from the JSON in the DB
        $orderTime = strtolower(json_decode($orderToUpdate->orderData)->cookType);
        $timeToFinish = time();
        $timeToFlip = time();

        // Calculate time to cook depending on the cooktype
        if ($orderTime === 'rare') {
            $timeToFinish += 180;
            $timeToFlip += 90;
        }
        if ($orderTime === 'medium-rare') {
            $timeToFinish += 240;
            $timeToFlip += 120;
        }
        if ($orderTime === 'medium') {
            $timeToFinish += 300;
            $timeToFlip += 150;
        }
        if ($orderTime === 'medium-well') {
            $timeToFinish += 360;
            $timeToFlip += 180;
        }
        if ($orderTime === 'well') {
            $timeToFinish += 240;
            $timeToFlip += 120;
        }

        // Update order in DB
        $orderToUpdate->timeToFlip = $timeToFlip;
        $orderToUpdate->timeToFinish = $timeToFinish;
        $orderToUpdate->update();

        return redirect()->to('/viewOrders');
    }

    // Called when "finish order" button is clicked by admin user (after burger finishTime hits 0)
    // Takes the burger out of the queue by changing a database boolean
    public function finishOrder(Request $request) {
        $this->validate($request, [
            'orderId' => 'bail|required|string'
        ]);

        $orderToUpdate = Order::where('id', $request->request->get('orderId'))->first();
        $orderToUpdate->completed = 1;
        $orderToUpdate->update();

        return redirect()->to('/viewOrders');
    }
}