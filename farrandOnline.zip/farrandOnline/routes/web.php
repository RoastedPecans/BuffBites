<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::post('/register', 'AccountController@register');
Route::get('/register', 'AccountController@registerView');
Route::post('/registerForm', "AccountController@registerFormPost");

Route::get('/login', 'AccountController@loginView');
Route::post('/login', 'AccountController@loginPost');
Route::post('/loginForm', 'AccountController@loginFormPost');

Route::post('/createOrder', 'OrderController@createOrder');
Route::post('/startOrder', 'OrderController@startOrder');
Route::post('/finishOrder', 'OrderController@finishOrder');

Route::get('/viewOrders', 'OrderController@viewOrders');

Route::get('/', function () {
    return view('home');
});
